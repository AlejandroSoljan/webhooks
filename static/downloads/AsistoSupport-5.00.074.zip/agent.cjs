// Asisto | Version: 5.00.074 | Fecha: 2026-09-09
const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');
const crypto = require('node:crypto');
const { storage } = require('./storage.cjs');
const { startLocal } = require('./local.cjs');
const BASE = 'https://asistobot.com.ar';
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

// Read a separate contact snapshot without rewinding Baileys' app-state versions,
// replacing authentication, or applying settings/messages from the snapshot.
async function readContactSnapshot(b, socket, readAuth, collection = 'critical_unblock_low') {
  const response = await socket.query({ tag: 'iq', attrs: { to: 's.whatsapp.net', xmlns: 'w:sync:app:state', type: 'set' }, content: [{ tag: 'sync', attrs: {}, content: [{ tag: 'collection', attrs: { name: collection, version: '0', return_snapshot: 'true' } }] }] }, 15000);
  const result = (await b.extractSyncdPatches(response, { signal: AbortSignal.timeout(30000) }))[collection];
  if (!result?.snapshot) throw new Error('contact_snapshot_unavailable');
  const keyCache = new Map();
  const getKey = async key => { if (!keyCache.has(key)) keyCache.set(key, readAuth('app-state-sync-key:' + key)); return keyCache.get(key); }, logger = require('pino')({ level: 'silent' });
  const decoded = await b.decodeSyncdSnapshot(collection, result.snapshot, getKey, undefined, true, logger);
  let state = decoded.state, batch = result;
  for (let page = 0; page < 10; page++) {
    if (batch.patches?.length) {
      const delta = await b.decodePatches(collection, batch.patches, state, getKey, { signal: AbortSignal.timeout(30000) }, undefined, logger);
      state = delta.state; Object.assign(decoded.mutationMap, delta.mutationMap);
    }
    if (!batch.hasMorePatches) break;
    if (page === 9) throw new Error('contact_snapshot_incomplete');
    const more = await socket.query({ tag: 'iq', attrs: { to: 's.whatsapp.net', xmlns: 'w:sync:app:state', type: 'set' }, content: [{ tag: 'sync', attrs: {}, content: [{ tag: 'collection', attrs: { name: collection, version: String(state.version), return_snapshot: 'false' } }] }] }, 15000);
    batch = (await b.extractSyncdPatches(more, { signal: AbortSignal.timeout(30000) }))[collection];
    if (!batch) throw new Error('contact_snapshot_incomplete');
  }
  const contacts = [];
  const actions = {};
  for (const mutation of Object.values(decoded.mutationMap)) {
    for (const key of Object.keys(mutation.syncAction?.value || {})) if (key.endsWith('Action')) actions[key] = (actions[key] || 0) + 1;
    const action = mutation.syncAction?.value?.contactAction || mutation.syncAction?.value?.lidContactAction;
    const id = mutation.index?.[1];
    if (!action || !/^[0-9]+@(s\.whatsapp\.net|lid)$/.test(id || '')) continue;
    const name = action.fullName || action.firstName || action.username;
    if (!name) continue;
    const user = id.split('@')[0], isLid = id.endsWith('@lid');
    const mapped = readAuth('lid-mapping:' + user + (isLid ? '_reverse' : ''));
    contacts.push({ id, name, lid: action.lidJid || (isLid ? id : typeof mapped === 'string' && /^\d+$/.test(mapped) ? mapped + '@lid' : undefined), phoneNumber: action.pnJid || (!isLid ? id : typeof mapped === 'string' && /^\d+$/.test(mapped) ? mapped + '@s.whatsapp.net' : undefined) });
  }
  contacts.diagnostics = { collection, mutations: Object.keys(decoded.mutationMap).length, actions };
  return contacts;
}

async function run(options = {}) {
  const profile = options.profile || process.argv[2];
  if (!profile || !path.isAbsolute(profile)) throw new Error('Profile required');
  const store = options.store || storage(profile), instance = crypto.randomUUID(), pause = options.sleep || sleep;
  const status = value => fs.writeFileSync(path.join(profile, 'status.json'), JSON.stringify({ ...value, updatedAt: new Date().toISOString() }));
  let account = store.read('account'), socket, socketGeneration = 0, stopped = false, retryAt = 0, tail = Promise.resolve();
  const b = await (options.loadBaileys || (() => import('@whiskeysockets/baileys')))();
  const request = async (route, body = {}) => {
    const response = await (options.fetchImpl || fetch)(BASE + '/api/support/device/' + route, { method: 'POST', redirect: 'error', signal: AbortSignal.timeout(15000), headers: { 'Content-Type': 'application/json', 'X-Asisto-Instance': instance, ...(account?.token ? { Authorization: 'Bearer ' + account.token } : {}) }, body: JSON.stringify(body) });
    if (!response.ok) { const error = new Error('Agent request failed'); error.status = response.status; throw error; }
    return response.json();
  };
  const stopSocket = () => { socketGeneration++; const current = socket; socket = undefined; current?.end(undefined); };
  const quit = () => { stopped = true; stopSocket(); };
  process.on('SIGINT', quit); process.on('SIGTERM', quit);
  if (!account?.approved) {
    if (!account || new Date(account.expiresAt) <= new Date()) {
      account = await request('start', { name: os.hostname(), sessionsPanel: true }); store.write('account', account);
    }
    // Publish the pairing link for manual opening; the background agent never opens a browser.
    const url = new URL(account.verificationUrl);
    if (url.origin !== BASE || !['/ui/support', '/admin/wweb'].includes(url.pathname)) throw new Error('Invalid approval URL');
    status({ state: 'awaiting_approval', verificationUrl: url.href });
    while (!stopped && new Date(account.expiresAt) > new Date()) {
      try {
        const state = await request('poll');
        if (state.state === 'approved') { account = { ...account, ...state, approved: true }; store.write('account', account); break; }
      } catch (error) { if (error.status === 401) { store.write('account', null); return; } }
      await pause(3000);
    }
    if (!account.approved || stopped) return;
  }
  // Auth remains on this Windows user's PC. No MongoDB or global Asisto secret.
  const readAuth = id => { const value = store.read('auth:' + id); return value ? JSON.parse(value, b.BufferJSON.reviver) : null; };
  const writeAuth = (id, value) => {
    const ids = store.read('auth-index') || [];
    if (!ids.includes(id)) store.write('auth-index', [...ids, id]);
    store.write('auth:' + id, value == null ? null : JSON.stringify(value, b.BufferJSON.replacer));
  };
  const clearAuth = () => { for (const id of store.read('auth-index') || []) store.write('auth:' + id, null); store.write('auth-index', []); };
  // Preserve the saved queue order without reading thousands of payload files at startup.
  const order = new Map(Object.entries(store.read('outbox-order') || {})), seen = new Set(store.read('outbox-index') || []);
  const contacts = store.read('contacts') || {}, contactPending = new Set(store.read('contacts-pending') || []);
  const contactName = jid => contacts[jid]?.name || contacts[jid]?.notify || contacts[jid]?.verifiedName || '';
  const rememberContacts = updates => {
    let changed = false;
    for (const update of updates || []) {
      const aliases = [update.id, update.lid, update.phoneNumber].filter(id => /^[^@]+@(s\.whatsapp\.net|lid)$/.test(id || ''));
      for (const jid of aliases) {
        const next = { ...contacts[jid] };
        next.aliases = [...new Set([...(next.aliases || []), ...aliases])].slice(0, 5);
        for (const key of ['name', 'notify', 'verifiedName']) if (typeof update[key] === 'string' && update[key].trim()) next[key] = update[key].trim().slice(0, 200);
        if (JSON.stringify(next) !== JSON.stringify(contacts[jid] || {})) { contacts[jid] = next; contactPending.add(jid); changed = true; }
      }
    }
    if (changed) { store.write('contacts', contacts); store.write('contacts-pending', [...contactPending]); }
  };
  let uploadLimit = 25;
  const recentFirst = ids => ids.sort((a, b) => (order.get(b) || 0) - (order.get(a) || 0));
  const queue = async (messages, historical = false) => {
    for (let offset = 0; offset < messages.length; offset += 50) {
      rememberContacts(messages.slice(offset, offset + 50).filter(raw => !raw.key?.fromMe && raw.pushName).map(raw => ({ id: raw.key?.remoteJid, notify: raw.pushName })));
      const index = new Set(store.read('outbox-index') || []);
      let changed = false;
      for (const raw of messages.slice(offset, offset + 50)) {
      const msg = b.normalizeMessageContent(raw.message), jid = raw.key?.remoteJid;
      if (!msg || !raw.key?.id || !/^[^@]+@(s\.whatsapp\.net|lid)$/.test(jid || '')) continue;
      const content = msg.conversation || msg.extendedTextMessage?.text || msg.imageMessage?.caption || msg.documentMessage?.caption || '';
      if (!content && !msg.audioMessage) continue;
      const audio = msg.audioMessage;
      const message = { id: raw.key.id, jid, fromMe: !!raw.key.fromMe, name: contactName(jid), at: new Date(Number(raw.messageTimestamp) * 1000).toISOString(), text: content.length > 20000 ? '' : content, contentTooLarge: content.length > 20000, audio: audio ? { seconds: Number(audio.seconds || 0), mimetype: audio.mimetype || 'audio/ogg', bytes: Number(audio.fileLength || 0) } : null, raw: audio ? JSON.stringify(raw, b.BufferJSON.replacer) : null };
      const id = crypto.createHash('sha256').update(JSON.stringify([jid, raw.key.id, !!raw.key.fromMe])).digest('hex');
      // An interrupted upload is replayed idempotently using the WhatsApp ID.
      if (!seen.has(id)) { store.write('outbox:' + id, { ...message, historical }); index.add(id); seen.add(id); order.set(id, Date.parse(message.at)); changed = true; }
      }
      if (changed) { store.write('outbox-index', recentFirst([...index])); store.write('outbox-order', Object.fromEntries(order)); }
      // Large history events must yield so heartbeat and uploads keep running.
      await pause(0);
    }
  };
  const connect = () => {
    const creds = readAuth('creds') || b.initAuthCreds(); writeAuth('creds', creds);
    const generation = ++socketGeneration;
    const active = b.default({ auth: { creds, keys: {
      async get(type, ids) { const result = {}; for (const id of ids) { let value = readAuth(type + ':' + id); if (type === 'app-state-sync-key' && value) value = b.proto.Message.AppStateSyncKeyData.fromObject(value); result[id] = value; } return result; },
      async set(data) { for (const [type, values] of Object.entries(data)) for (const [id, value] of Object.entries(values)) writeAuth(type + ':' + id, value); },
    } }, logger: require('pino')({ level: 'silent' }), markOnlineOnConnect: false, syncFullHistory: true, shouldSyncHistoryMessage: () => true, shouldIgnoreJid: jid => /@(g\.us|broadcast|newsletter)$/.test(jid), getMessage: async () => undefined });
    socket = active;
    const event = fn => { tail = tail.then(async () => { if (generation === socketGeneration) await fn(); }).catch(() => { if (generation === socketGeneration) { stopSocket(); retryAt = Date.now() + 15000; } }); };
    active.ev.on('creds.update', () => event(() => writeAuth('creds', creds)));
    active.ev.on('messages.upsert', update => event(() => queue(update.messages, update.type === 'append')));
    active.ev.on('messaging-history.set', update => event(() => { rememberContacts(update.contacts); return queue(update.messages || [], true); }));
    active.ev.on('contacts.upsert', updates => event(() => rememberContacts(updates)));
    active.ev.on('contacts.update', updates => event(() => rememberContacts(updates)));
    active.ev.on('connection.update', update => event(async () => {
      if (update.qr) await request('session', { state: 'qr', qr: update.qr });
      if (update.connection === 'open') {
        const connected = await request('session', { state: 'connected', number: active.user?.id || creds.me?.id || '' });
        if (connected?.ok === false && connected.error === 'number_mismatch') {
          try { await active.logout?.(); } catch {}
          clearAuth(); stopSocket(); retryAt = Date.now() + 10000;
          status({ state: 'number_mismatch', whatsapp: 'disconnected' });
          return;
        }
        const snapshot = store.read('contact-snapshot') || {};
        if (active.query && b.extractSyncdPatches && !snapshot.completed && (!snapshot.retryAt || Date.now() >= snapshot.retryAt)) {
          try {
            const restored = [], diagnostics = [];
            for (const collection of ['critical_unblock_low', 'critical_block', 'regular_low', 'regular', 'regular_high']) {
              const rows = await readContactSnapshot(b, active, readAuth, collection);
              restored.push(...rows); diagnostics.push(rows.diagnostics);
              if (rows.length) break;
            }
            if (generation === socketGeneration) { rememberContacts(restored); store.write('contact-snapshot', { completed: restored.length > 0, count: restored.length, diagnostics, retryAt: Date.now() + 3600000 }); }
          } catch { store.write('contact-snapshot', { retryAt: Date.now() + 3600000 }); }
        }
      }
      if (update.connection === 'close') {
        socket = undefined; retryAt = Date.now() + 10000;
        const logout = update.lastDisconnect?.error?.output?.statusCode === b.DisconnectReason.loggedOut;
        if (logout) clearAuth();
        await request('session', { state: logout ? 'logged_out' : 'reconnecting' });
      }
    }));
  };
  while (!stopped) {
    try {
      const state = await request('heartbeat', { queuedMessages: (store.read('outbox-index') || []).length });
      status({ state: state.configurationRequired ? 'configuration_required' : 'active', whatsapp: state.desired });
      if (state.desired !== 'connected') {
        if (socket) { stopSocket(); await request('session', { state: 'disconnected' }); }
      } else if (!socket && Date.now() >= retryAt) connect();
      const contactBatch = state.validated ? [...contactPending].slice(0, 50).map(jid => ({ jid, name: contactName(jid), aliases: contacts[jid]?.aliases || [] })).filter(contact => contact.name) : [];
      if (contactBatch.length) {
        await request('contacts', { contacts: contactBatch });
        for (const contact of contactBatch) if (contactName(contact.jid) === contact.name) contactPending.delete(contact.jid);
        store.write('contacts-pending', [...contactPending]);
      }
      // Processing must progress even when a subsequent upload times out.
      await request('work');
      await request('heartbeat', { queuedMessages: (store.read('outbox-index') || []).length });
      // Bounded batches avoid one HTTP request and one full index rewrite per message.
      const messages = [], ids = [];
      for (const id of (store.read('outbox-index') || []).slice(0, uploadLimit)) {
        const message = store.read('outbox:' + id);
        if (message && Buffer.byteLength(JSON.stringify({ messages: [...messages, message] })) > 110000) break;
        ids.push(id); if (message) messages.push(message);
      }
      if (messages.length && state.validated) {
        try { await request('messages', { messages }); }
        catch (error) { uploadLimit = Math.max(1, Math.floor(uploadLimit / 2)); throw error; }
      }
      if (ids.length && state.validated) {
        const sent = new Set(ids);
        store.write('outbox-index', (store.read('outbox-index') || []).filter(value => !sent.has(value)));
        for (const id of ids) store.write('outbox:' + id, null);
      }
      await request('heartbeat', { queuedMessages: (store.read('outbox-index') || []).length });
    } catch (error) {
      if (error.status === 401 || error.status === 403) { stopSocket(); status({ state: 'access_revoked' }); process.exitCode = 2; return; }
      if (error.status === 409) stopSocket();
      // A slow Asisto request does not require reconnecting WhatsApp and importing history again.
      status({ state: 'retrying', error: error.status || error.name, uploadLimit });
    }
    await pause((store.read('outbox-index') || []).length ? 250 : 5000);
  }
  await tail;
}
async function main() {
  const profile = process.argv[2], store = storage(profile);
  const local = await startLocal({ readAccount: () => store.read('account') });
  try { await run({ profile, store }); }
  finally { local.closeAllConnections(); await new Promise(resolve => local.close(resolve)); }
}
if (require.main === module) main().catch(() => { console.error('Asisto: no se pudo iniciar el agente. Se reintentará automáticamente.'); process.exitCode = 1; });
module.exports = { run, readContactSnapshot };
