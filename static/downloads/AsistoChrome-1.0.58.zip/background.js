// Asisto | Version: 5.00.269 | Fecha: 2026-09-29
const BASE = 'https://asistobot.com.ar/api/support/extension';
const LOCAL = 'http://127.0.0.1:17658/extension-session';
async function request(path, token, body, grant) {
  const response = await fetch(BASE + path, { credentials: 'omit', redirect: 'error', cache: 'no-store', signal: AbortSignal.timeout(30000), headers: {
    'X-Asisto-Extension-Id': chrome.runtime.id, Authorization: 'Bearer ' + token, ...(body ? { 'Content-Type': 'application/json', 'X-Asisto-Extension': grant } : {}),
  }, ...(body ? { method: 'POST', body: JSON.stringify(body) } : {}) });
  if (!response.headers.get('content-type')?.includes('application/json')) throw new Error('authentication_required');
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || 'request_failed');
  return result;
}
async function authenticatedSession() {
  // The local WhatsApp agent owns this workflow. A browser cookie may belong
  // to another tenant and must never select the extension's account.
  const local = await fetch(LOCAL, { cache: 'no-store', signal: AbortSignal.timeout(5000), headers: { 'X-Asisto-Local': '1', 'X-Asisto-Extension-Id': chrome.runtime.id } });
  if (local.status === 403) throw new Error('agent_access_denied');
  if (!local.ok || !local.headers.get('content-type')?.includes('application/json')) throw new Error('agent_not_authorized');
  const result = await local.json();
  const token = result.token;
  if (!/^[A-Za-z0-9_-]{43}$/.test(token || '')) throw new Error('agent_not_authorized');
  return { session: await request('/session', token), token };
}
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  const fromWhatsApp = sender.tab && sender.url?.startsWith('https://web.whatsapp.com/');
  const fromPanel = sender.url === chrome.runtime.getURL('panel.html');
  if (sender.id !== chrome.runtime.id || (!fromWhatsApp && !fromPanel)) return false;
  if (message.action === 'OPEN' && fromWhatsApp) {
    // Called immediately inside the click message to preserve Chrome's user gesture.
    const opened = chrome.sidePanel.open({ tabId: sender.tab.id });
    Promise.all([opened, chrome.storage.session.set({ ['selection-' + sender.tab.id]: { jid: String(message.jid || ''), name: String(message.name || ''), draftId: String(message.draftId || ''), refreshAt: Date.now() } })]).then(() => reply({ ok: true }), () => reply({ error: 'panel_open_failed' }));
    return true;
  }
  if (message.action === 'SET_CONTEXT' && fromWhatsApp) {
    const key = 'selection-' + sender.tab.id;
    chrome.storage.session.get(key).then(stored => {
      const previous = stored[key], jid = String(message.jid || ''), name = String(message.name || ''), draftId = String(message.draftId || '');
      if (message.refresh !== true && previous?.jid === jid && previous?.name === name && !draftId) return { unchanged: true };
      return chrome.storage.session.set({ [key]: { jid, name, draftId, refreshAt: Date.now() } }).then(() => ({ unchanged: false }));
    }).then(result => reply({ ok: true, ...result }), () => reply({ error: 'context_failed' }));
    return true;
  }
  if (fromWhatsApp && !['INDEX', 'CONTACT', 'CONTACTS', 'MESSAGES', 'ASSIGN_MESSAGES', 'ACTIVE_CONTEXT'].includes(message.action)) return false;
  (async () => {
    const { session, token } = await authenticatedSession();
    const api = (path, body, grant) => request(path, token, body, grant);
    if (message.action === 'SESSION') return { ...session, csrf: undefined };
    if (message.action === 'INDEX') {
      if (sender.tab?.id) chrome.sidePanel.setOptions?.({ tabId: sender.tab.id, path: 'panel.html', enabled: true }).catch(() => {});
      return { ...await api('/index'), owner: session.tenantId + ':' + session.userId };
    }
    if (message.action === 'ACTIVE_CONTEXT' && sender.tab?.id) {
      const key = 'selection-' + sender.tab.id, stored = await chrome.storage.session.get(key);
      return stored[key] || null;
    }
    if (message.owner && message.owner !== session.tenantId + ':' + session.userId) throw new Error('account_changed');
    const id = encodeURIComponent(String(message.id || ''));
    switch (message.action) {
      case 'CONTACT_CONTROL': return api('/contact-control?q=' + encodeURIComponent(String(message.query || '')));
      case 'SET_CONTACT_CONTROL': return api('/contact-control', { jid: String(message.jid || ''), excluded: message.excluded === true }, session.csrf);
      case 'CONTACT': return api('/contact', { jid: String(message.jid || ''), name: String(message.name || '') }, session.csrf);
      case 'CONTACTS': return api('/contacts', { contacts: Array.isArray(message.contacts) ? message.contacts : [] }, session.csrf);
      case 'DRAFTS': return api('/drafts?jid=' + encodeURIComponent(String(message.jid || '')));
      case 'MESSAGES': return api('/messages?jid=' + encodeURIComponent(String(message.jid || '')));
      case 'ASSIGN_MESSAGES': return api('/messages/assign', { jid: String(message.jid || ''), messageIds: Array.isArray(message.messageIds) ? message.messageIds : [], selectedMessages: Array.isArray(message.selectedMessages) ? message.selectedMessages : [], destination: String(message.destination || ''), existingAction: String(message.existingAction || ''), reassign: message.reassign === true, duplicate: message.duplicate === true }, session.csrf);
      case 'DETAIL': return api('/drafts/' + id);
      case 'SAVE': return api('/drafts/' + id + '/save', { revision: message.revision, fields: message.fields }, session.csrf);
      case 'RECONCILE': return api('/drafts/' + id + '/reconcile', { revision: message.revision, fields: message.fields }, session.csrf);
      case 'QUEUE': return api('/drafts/' + id + '/queue', { revision: message.revision }, session.csrf);
      case 'MANUAL_HUBSPOT': {
        const job = { id: message.id, revision: message.revision, fields: message.fields, owner: session.tenantId + ':' + session.userId, createdAt: Date.now() };
        await chrome.storage.session.set({ hubspotManualJob: job });
        const tabs = await chrome.tabs.query({ url: 'https://app.hubspot.com/*' });
        if (tabs[0]?.id) {
          await chrome.tabs.update(tabs[0].id, { active: true }); await chrome.windows.update(tabs[0].windowId, { focused: true });
          await chrome.scripting.executeScript({ target: { tabId: tabs[0].id }, files: ['hubspot-ui.js'] });
        }
        else await chrome.tabs.create({ url: 'https://app.hubspot.com/contacts/', active: true });
        return { started: true };
      }
      case 'DISMISS': return api('/drafts/' + id + '/dismiss', { revision: message.revision }, session.csrf);
      case 'DISCARD_CHANGES': return api('/drafts/' + id + '/discard-changes', { revision: message.revision }, session.csrf);
      case 'HUBSPOT': return api('/hubspot');
      case 'MAIL_SETTINGS': return api('/mail/settings');
      case 'MAIL_SAVE': return api('/mail/settings', message.config, session.csrf);
      case 'MAIL_VERIFY': return api('/mail/verify', {}, session.csrf);
      case 'MAIL_HISTORY': return api('/drafts/' + id + '/mail');
      case 'MAIL_SEND': return api('/drafts/' + id + '/mail', message.mail, session.csrf);
      case 'COMPANY_PROFILE': return api('/hubspot/company?id=' + encodeURIComponent(String(message.companyId || '')) + '&jid=' + encodeURIComponent(String(message.jid || '')));
    case 'MAIL_CONTACTS': return api('/hubspot/mail-contacts');
    case 'HUBSPOT_SEARCH': return api('/hubspot/search?type=' + encodeURIComponent(String(message.type || '')) + '&q=' + encodeURIComponent(String(message.query || '')));
      case 'CONNECT': return api('/hubspot/connect', { token: message.token }, session.csrf);
      case 'PUBLISH': return api('/drafts/' + id + '/publish', { revision: message.revision, mapping: message.mapping }, session.csrf);
      default: throw new Error('invalid_action');
    }
  })().then(data => reply({ data }), error => reply({ error: error.message === 'Failed to fetch' ? 'connection_failed' : error.message }));
  return true;
});
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (sender.id !== chrome.runtime.id || !sender.url?.startsWith('https://app.hubspot.com/')) return false;
  (async () => {
    const stored = await chrome.storage.session.get('hubspotManualJob'), job = stored.hubspotManualJob;
    if (message.action === 'HUBSPOT_UI_READY') return job && Date.now() - job.createdAt < 15 * 60 * 1000 ? job : null;
    if (message.action === 'HUBSPOT_UI_COMPLETE' && job && message.id === job.id) {
      const { session, token } = await authenticatedSession();
      const result = await request('/drafts/' + encodeURIComponent(job.id) + '/manual-complete', token, { revision: job.revision, ticketId: String(message.ticketId || 'manual') }, session.csrf);
      await chrome.storage.session.remove('hubspotManualJob');
      return result;
    }
    if (message.action === 'HUBSPOT_UI_FAILED' && job) { await chrome.storage.session.set({ hubspotManualResult: { error: String(message.error || 'No se pudo completar HubSpot'), at: Date.now() } }); await chrome.storage.session.remove('hubspotManualJob'); return { saved: false }; }
    return null;
  })().then(data => reply({ data }), error => reply({ error: error.message }));
  return true;
});
chrome.action.onClicked.addListener(tab => { if (tab.id) { chrome.sidePanel.setOptions?.({ tabId: tab.id, path: 'panel.html', enabled: true }).catch(() => {}); chrome.sidePanel.open({ tabId: tab.id }).catch(() => {}); } });
